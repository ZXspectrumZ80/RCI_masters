euroc_comm
==========

euroc (simulation) specific messages/services that do not fit anywhere else
