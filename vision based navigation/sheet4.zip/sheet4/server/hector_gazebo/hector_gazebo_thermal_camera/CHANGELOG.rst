^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_gazebo_thermal_camera
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.3 (2014-05-27)
------------------
* Fix bad bug with index access
* Contributors: Stefan Kohlbrecher

0.3.2 (2014-03-30)
------------------
* added missing dependency to roscpp
* hector_gazebo: deleted deprecated export sections from package.xml files
* Contributors: Johannes Meyer

0.3.1 (2013-09-23)
------------------
* fixed image_connect_count_ compile issues with the latest gazebo_plugins version 2.3.2

0.3.0 (2013-09-02)
------------------
* Catkinization of stack hector_gazebo
