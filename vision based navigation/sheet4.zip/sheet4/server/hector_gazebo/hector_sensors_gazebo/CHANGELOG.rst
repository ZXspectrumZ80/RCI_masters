^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_sensors_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.3 (2014-05-27)
------------------

0.3.2 (2014-03-30)
------------------
* removed metapackage tag from hector_sensors_gazebo to not break packages depending on it
* hector_gazebo: Made hector_gazebo and hector_sensors_gazebo true metapackages
* Moved package from hector_models to hector_gazebo
* Contributors: Johannes Meyer

0.3.0 (2013-09-02)
------------------
* catkinized stack hector_models
