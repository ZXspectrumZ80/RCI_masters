euroc_simulator
===============

simulator for the EuRoC MAV challenge
