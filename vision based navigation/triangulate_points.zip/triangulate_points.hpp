cv::Mat linearLSTriangulation(cv::Vec2d u1, // image point in camera 1       
                   cv::Mat P1,       // camera 1 projection matrix
                   cv::Vec2d u2,      // image point in camera 2
                   cv::Mat P2       // camera 2 projection matrix
                                   )
{

    cv::Mat A = (cv::Mat_<double>(4,3) << u1[0]*P1.at<double>(2,0)-P1.at<double>(0,0),    u1[0]*P1.at<double>(2,1)-P1.at<double>(0,1),      u1[0]*P1.at<double>(2,2)-P1.at<double>(0,2),
          u1[1]*P1.at<double>(2,0)-P1.at<double>(1,0),    u1[1]*P1.at<double>(2,1)-P1.at<double>(1,1),      u1[1]*P1.at<double>(2,2)-P1.at<double>(1,2),
          u2[0]*P2.at<double>(2,0)-P2.at<double>(0,0), u2[0]*P2.at<double>(2,1)-P2.at<double>(0,1),   u2[0]*P2.at<double>(2,2)-P2.at<double>(0,2),
          u2[1]*P2.at<double>(2,0)-P2.at<double>(1,0), u2[1]*P2.at<double>(2,1)-P2.at<double>(1,1),   u2[1]*P2.at<double>(2,2)-P2.at<double>(1,2)
              );
    cv::Mat B = (cv::Mat_<double>(4,1) <<    -(u1[0]*P1.at<double>(2,3)    -P1.at<double>(0,3)),
                      -(u1[1]*P1.at<double>(2,3)  -P1.at<double>(1,3)),
                      -(u2[0]*P2.at<double>(2,3)    -P2.at<double>(0,3)),
                      -(u2[1]*P2.at<double>(2,3)    -P2.at<double>(1,3)));
 
    cv::Mat X;
    cv::solve(A,B,X,cv::DECOMP_SVD);
 
    return X;
}


// note: points that could not be triangulated will have 0's in the 4th component
void triangulatePoints2( cv::Mat P1, cv::Mat P2, cv::Mat pts1, cv::Mat pts2, cv::Mat& pts_out ) {
  
  pts_out = cv::Mat( 4, pts1.cols, CV_64FC1, 0.f );
  
  for( unsigned int i = 0; i < pts1.cols; i++ ) {
    
    cv::Mat p_out = pts_out.col( i );
    cv::Mat p_tri = linearLSTriangulation( pts1.at<cv::Vec2d>(0,i), P1, pts2.at<cv::Vec2d>(0,i), P2 );
    
    if( isnan(p_tri.at<double>( 0, 0 )) || isnan(p_tri.at<double>( 1, 0 )) || isnan(p_tri.at<double>( 2, 0 )) )
      continue;
    
    pts_out.at<double>( 0, i ) = p_tri.at<double>( 0, 0 );
    pts_out.at<double>( 1, i ) = p_tri.at<double>( 1, 0 );
    pts_out.at<double>( 2, i ) = p_tri.at<double>( 2, 0 );
    pts_out.at<double>( 3, i ) = 1;
        
  }
  
}

