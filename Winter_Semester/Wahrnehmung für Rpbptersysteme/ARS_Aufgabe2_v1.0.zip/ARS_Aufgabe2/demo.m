%% Lade Bilder (Szene und Modell)
model = imread('fritz_model.png');
model = imresize(model, 0.5);
% imshow(model);

scene = imread('fritz_scene.png');
% imshow(scene);

%% Lade Kalibierungsergebnis

load('calibrationSession');

%% Wandle Farb- in Graubilder um, weil die SURF-Features Farbe nicht brauchen (können)
boxImage = rgb2gray(model);
sceneImage = undistortImage(rgb2gray(scene),calibrationSession.CameraParameters);
%sceneImage = rgb2gray(scene);

%% Bestimme Modellabmessungen (Die Box war 127mm breit, gemessen mit Lineal....)
modelWidth = .127;
modelscale = modelWidth / size(boxImage,2);
modelHeight = modelscale * size(boxImage,1);

%% Feature-Extraktion ( SURF features ) und Anzeige
scenePoints = detectSURFFeatures(sceneImage);
boxPoints = detectSURFFeatures(boxImage);

figure; imshow(boxImage); hold; plot(boxPoints);
figure; imshow(sceneImage);hold; plot(scenePoints);

[boxFeatures, boxPoints] = extractFeatures(boxImage, boxPoints);
[sceneFeatures, scenePoints] = extractFeatures(sceneImage, scenePoints);

%% Featurematching anhand der Deskriptoren
boxPairs = matchFeatures(boxFeatures, sceneFeatures);
noMatches = size(boxPairs,1);

allMatchedBoxPoints = boxPoints(boxPairs(:, 1), :);
allMatchedScenePoints = scenePoints(boxPairs(:, 2), :);

figure;
showMatchedFeatures(boxImage, sceneImage, allMatchedBoxPoints, allMatchedScenePoints, 'montage');

%% rekonstuktion der 6D-Pose (MATLABs extrincics funktion)
allScenepoints = double(allMatchedScenePoints.Location);
allBoxpoints = double(allMatchedBoxPoints.Location) * modelscale;
[rotationMatrix,translationVector] = extrinsics(allScenepoints,allBoxpoints,calibrationSession.CameraParameters);


%% Projektion der Objektecken ins Bild zu Kontrollzwecken
boundingRect = [0,0,0,1; 0,modelHeight,0,1; modelWidth, 0, 0, 1; modelWidth,modelHeight, 0,1]; 
projectedRect = boundingRect * [rotationMatrix; translationVector] * calibrationSession.CameraParameters.IntrinsicMatrix;
camPoints = [projectedRect(:,1)./projectedRect(:,3) , projectedRect(:,2)./projectedRect(:,3)];
figure; imagesc(sceneImage); hold; axis equal; scatter(camPoints(:,1),camPoints(:,2));

%% Outlierremoval mit RANSAC
maxInliers = 3;
for i = [1:300]
    % Erzeuge ein zufälliges Tripel von Matches
    len = 0;
    while len < 4
        quadruple = unique(randi([1 noMatches],4,1));
        len = length( quadruple);
    end
    
    %Bestimme die Objektlage auf der basis der drei Matches
    matchedBoxPoints = boxPoints(boxPairs(quadruple, 1), :);
    matchedScenePoints = scenePoints(boxPairs(quadruple, 2), :);
    
    scenepoints = double(matchedScenePoints.Location);
    boxpoints = double(matchedBoxPoints.Location) * modelscale;

    % figure; showMatchedFeatures(boxImage, sceneImage, matchedBoxPoints, matchedScenePoints, 'montage');
    try
    [rotationMatrix,translationVector] = extrinsics(scenepoints,boxpoints,calibrationSession.CameraParameters); 
    catch err
        continue;
    end
    % bestimme die Anzahl der passenden Matches
    controlPoints = [allBoxpoints  repmat([0 1],size(allBoxpoints,1),1)];
    reprojectedPoints = controlPoints * [rotationMatrix; translationVector] * calibrationSession.CameraParameters.IntrinsicMatrix;
    camPoints = [reprojectedPoints(:,1)./reprojectedPoints(:,3) , reprojectedPoints(:,2)./reprojectedPoints(:,3)];
    % figure; imagesc(sceneImage); hold; axis equal; scatter(camPoints(:,1),camPoints(:,2),'o'); scatter(allScenepoints(:,1),allScenepoints(:,2),'+');
    
    diff = allScenepoints - camPoints;
    dist = hypot(diff(:,1),diff(:,1));
    idxInliers = dist<1;
    noInliers = length(dist(idxInliers));
    
    if (noInliers > maxInliers)
        theQuadruple = quadruple
        maxInliers = noInliers
        theInliers = idxInliers;
        [theRotationMatrix,theTranslationVector] = extrinsics(allScenepoints(theInliers,:),allBoxpoints(theInliers,:),calibrationSession.CameraParameters);
    end
end

%% Anzeige des Ergebnisses

controlPoints = [allBoxpoints  repmat([0 1],size(allBoxpoints,1),1)];
reprojectedPoints = controlPoints * [theRotationMatrix; theTranslationVector] * calibrationSession.CameraParameters.IntrinsicMatrix;
camPoints = [reprojectedPoints(:,1)./reprojectedPoints(:,3) , reprojectedPoints(:,2)./reprojectedPoints(:,3)];

figure; imagesc(sceneImage); hold; axis equal; scatter(camPoints(:,1),camPoints(:,2),'o'); scatter(allScenepoints(:,1),allScenepoints(:,2),'+');

projectedRect = boundingRect * [theRotationMatrix; theTranslationVector] * calibrationSession.CameraParameters.IntrinsicMatrix;
camPoints = [projectedRect(:,1)./projectedRect(:,3) , projectedRect(:,2)./projectedRect(:,3)];

figure; imagesc(sceneImage); hold; axis equal; scatter(camPoints(:,1),camPoints(:,2));


%% Berechnung der Kovarianzmatrix (nur Translation)

% Generate uniformly distributed samples around estimated translation
% vector
noSamples = 10000;
translationSamples = ((rand(noSamples,3) - 0.5) * 2 * 0.01) + repmat( theTranslationVector, noSamples,1);
% scatter3(translationSamples(:,1),translationSamples(:,2),translationSamples(:,3))


mean = zeros(1,3);
normalizer = 0;
for sample = [1:noSamples]
    reprojectedPoints = controlPoints * [theRotationMatrix; translationSamples(sample,:)] * calibrationSession.CameraParameters.IntrinsicMatrix;
    camPoints = [reprojectedPoints(:,1)./reprojectedPoints(:,3) , reprojectedPoints(:,2)./reprojectedPoints(:,3)];
    diff = allScenepoints - camPoints;
    dist = hypot(diff(:,1),diff(:,1));
    
    prob = exp(sum(-dist(theInliers).^2/(2*2)));
    normalizer = normalizer + prob;
    mean = mean + prob * translationSamples(sample,:);
end

mean = mean / normalizer;
mean - theTranslationVector


normalizer = 0;
cov = zeros(3,3);
for sample = [1:noSamples]
    reprojectedPoints = controlPoints * [theRotationMatrix; translationSamples(sample,:)] * calibrationSession.CameraParameters.IntrinsicMatrix;
    camPoints = [reprojectedPoints(:,1)./reprojectedPoints(:,3) , reprojectedPoints(:,2)./reprojectedPoints(:,3)];
    diff = allScenepoints - camPoints;
    dist = hypot(diff(:,1),diff(:,1));
    
    prob = prod(exp(-dist(theInliers).^2/(2*2)));
    normalizer = normalizer + prob;
    dx = translationSamples(sample,:)-mean;
    cov = cov + prob * dx' * dx;
end

cov = cov / normalizer;
sqrt(cov)

% Wichtige funktionen: 
%
% Hilfsfunktionen: imread, rgb2gray, imshow
%
% Kameramodell und 3D: undistortImage, extrinsics
%
% Lokale Merkmale: detectSURFFeatures, extractFeatures, matchFeatures, showMatchedFeatures
%

%
% Beispieldaten hereinladen
%
% model = imread('fritz_model.png');
% imshow(model);
% 
% scene = imread('fritz_scene.png');
% imshow(scene);
% 
% load('calibrationSession');
% 
% boxImage = rgb2gray(model);
% sceneImage = undistortImage(rgb2gray(scene),calibrationSession.CameraParameters);
% imshow(boxImage);
% imshow(sceneImage);


