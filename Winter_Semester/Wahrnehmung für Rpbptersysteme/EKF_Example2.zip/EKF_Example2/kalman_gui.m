function varargout = kalman_gui(varargin)
% kalman_gui MATLAB code for kalman_gui.fig
%      kalman_gui, by itself, creates a new kalman_gui or raises the existing
%      singleton*.
%
%      H = kalman_gui returns the handle to a new kalman_gui or the handle to
%      the existing singleton*.
%
%      kalman_gui('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in kalman_gui.M with the given input arguments.
%
%      kalman_gui('Property','Value',...) creates a new kalman_gui or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before kalman_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to kalman_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help kalman_gui

% Last Modified by GUIDE v2.5 15-Jan-2014 18:45:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @kalman_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @kalman_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before kalman_gui is made visible.
function kalman_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to kalman_gui (see VARARGIN)

% Choose default command line output for kalman_gui
handles.output = hObject;

global L;

L.active = false;
handles.t = timer('TimerFcn',{@timer2_callback, handles.figure1},'ExecutionMode', 'fixedSpacing', 'Period', 0.1);

L.true_x = [0 1]';
L.figure = figure;
L.axes = axes;

set (L.figure, 'WindowButtonMotionFcn', @mouseMove);
set (L.figure, 'WindowButtonUpFcn', @buttonUp);
set (L.figure, 'WindowButtonDownFcn', @buttonDown);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes kalman_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);

function mouseMove (object, eventdata)
global L;

C = get (L.axes, 'CurrentPoint');
if (L.active == true) 
    L.true_x = [C(1,1) C(1,2)]' ;
end

function buttonUp (object, eventdata)
global L;
disp('u');
L.active = false;


function buttonDown(object, eventdata)
global L;
disp('d');
L.active = true;

% --- Outputs from this function are returned to the command line.
function varargout = kalman_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2
if get(hObject,'Value') == 1 
    disp('Starting timer');
    start(handles.t);
else disp('stoppping timer')
    stop(handles.t);
end


% --- Executes on button press in reinit.
function reinit_Callback(hObject, eventdata, handles)
% hObject    handle to reinit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global L;

L.statelen = 4;
L.measlen = 2;
L.processNoise = 0.001 * eye(L.statelen);

L.processNoise(3,3) = 0.01;
L.processNoise(4,4) = 0.01;

L.measNoise = 0.01 * eye(L.measlen);
%measNoise(2,2) = 1;
L.sensor1Pos = [ -2 -1]' ;
L.sensor2Pos = [ 2 -1]' ;
L.T = str2double(get(handles.edit1,'String'));


% initialize kalman filter
L.k1 = kalman3(L.processNoise, L.measNoise, L.statelen, L.measlen, L.sensor1Pos, L.sensor2Pos, L.T);
L.k1 = L.k1.init();



set(0,'CurrentFigure', L.figure);
set(L.figure,'CurrentAxes', L.axes)

plotcov2(L.k1.x(1:2), L.k1.Sigma(1:2,1:2));
hold on;
scatter(L.true_x(1,1), L.true_x(2,1));
axis (L.axes,[-3 3 -3 3]);
axis (L.axes,'equal');
axis (L.axes,'manual');
hold off;

set ( handles.checkbox2, 'Enable', 'on');


% --- Diese Funktion h�ngt am Timer wird zyklisch ausgef�hrt. Sie
% realisiert den Kalman zyklus aus predict/correct
function timer2_callback(hObject, event, object)
global L;

set(0,'CurrentFigure', L.figure);
set(L.figure,'CurrentAxes', L.axes)
%axes(handles.axes1); 

% simulate measurement
u = [0 0]';
measurement = L.k1.simulateMeasurement(L.true_x, L.measNoise);

% EKF step
L.k1 =  L.k1.predict(u);

[l.k1 d2] = L.k1.computeMahalanobis(measurement);

if (d2 < 9.0)
    L.k1 =  L.k1.correct(measurement);
else
    L.k1 = L.k1.noCorrect();
end

plotcov2(L.k1.x(1:2), L.k1.Sigma(1:2,1:2));
hold on;

scatter(L.true_x(1,1), L.true_x(2,1));
axis (L.axes,[-3 3 -3 3]);
axis (L.axes,'equal');
axis (L.axes,'manual');

hold off;

% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global L;
if get(handles.checkbox2,'Value') == 1 
    disp('Stopping timer...');
    stop(handles.t);
end
disp('Closing...');
delete(timerfind);
% Hint: delete(hObject) closes the figure
%%delete(L.figure);
delete(hObject);



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
global L;
L.T = str2double(get(hObject,'String')) ;

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
