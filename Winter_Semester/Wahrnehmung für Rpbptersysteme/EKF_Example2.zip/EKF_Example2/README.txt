EKF-Beispiel aus der ARP Vorlesung

Startpunkt ist kalman_gui.m. Die kalman3-Klasse findet sich im Unterverzeichnis 
"@kalman3" (das mu� bei MATLAB wohl so sein.). Die restlichen Dateien werden 
f�r das Plotten der Kovarianzellopsoide gebraucht und stammen vn openslam.org 
(tjtf).

Viel Spa�!

Geog von Wichert, 17.1.2013