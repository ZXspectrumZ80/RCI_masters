#include <iostream>

int main(int argc, char *argv[])
{
	double foo, bar;
	std::cin >> foo;
	std::cin >> bar;

	std::cout << (foo+bar)*0.5 << std::endl;

	return 0;
}
